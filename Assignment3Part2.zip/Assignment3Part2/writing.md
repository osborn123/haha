# Writing for Assignment&nbsp;3 Part&nbsp;2 2023 #

- **LIU XUCHEN**
- **s2420193**
- **06**
- **Neel Chaudhari**
- **2023-04-03**




## Acknowledgements ##

This Assignment was created from resources from the following sources:

To write my **Code** in IntelliJ I used knowledge taken from the
following lecture slides:
- Week 1:Getting Started and Conditionals and Loops.
- Week 2:Arrays and Functions from.
- Week 3:Classes and Objects and Testing and Debugging.
- Week 4:Java API and Collections.
- Week 5:Stack vs. Heap and Abstraction and Modularisation.
- Week 6:Creating Classes and Refactoring.
- Week 7:Inheritance A and B.
- Week 9:Abstract Classes and Interfaces and Object Design.

**Technology** used:

- IntelliJ for the Java IDE (Integrated Development Environment)
- Oracle for providing Java for use
 https://docs.oracle.com/en/java/javase/11/docs/api/

To **Gain Experience Coding** I completed all lab and tutorial Exercises provided in Object Oriented
Programming class resources


To **Understand the Assignment during the early stages** I get help
from piazza. This can be accessed from the link below:
- [Link to thread on Piazza](https://piazza.com/class/lbkxl8hz9he5ae/post/256)


| **The websites I learned new information that helped me write code as shown below<br/>(as order of difficulty)** | **Link**                                                                                                                                                                                                                                                                   |
|------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| What are Java Exceptions and how do they work - W3Schools                                                        | [Java Exceptions](https://www.w3schools.com/java/java_try_catch.asp)                                                                                                                                                                                                       |
| Advantages of Exceptions - Oracle                                                                                | [Advantages of Exceptions](https://docs.oracle.com/javase/tutorial/essential/exceptions/advantages.html)                                                                                                                                                                   |
| The try-with-resources statement - Oracle                                                                        | [try-with-resources Statement](https://docs.oracle.com/javase/tutorial/essential/exceptions/tryResourceClose.html)                                                                                                                                                         |
| How the class Throwable works - Oracle                                                                           | [Class Throwable](https://docs.oracle.com/javase/8/docs/api/java/lang/Throwable.html)                                                                                                                                                                                      |
| What does the Interface Comparator  <T> do - Oracle                                                              | [Interface Comparator <T>](https://docs.oracle.com/javase/8/docs/api/java/util/Comparator.html)                                                                                                                                                                            |
| Comparator naturalOrder() method in Java with examples - Geeksforgeeks                                           | [naturalOrder method and exaples](https://www.geeksforgeeks.org/comparator-naturalorder-method-in-java-with-examples/)                                                                                                                                                     |
| The Java String trim() method with example - Geeksforgeeks                                                       | [str.trim()](https://www.geeksforgeeks.org/java-string-trim-method-example/)                                                                                                                                                                                               |
| What can the class Scanner do - Oracle                                                                           | [Class Scanner](https://docs.oracle.com/javase/7/docs/api/java/util/Scanner.html)                                                                                                                                                                                          |
| Scanner Class in Java - Geeksforgeeks                                                                            | [Class Scanner](https://www.geeksforgeeks.org/scanner-class-in-java/)                                                                                                                                                                                                      |
| How does throw new exception work inside a catch - Stackoverflow                                                 | [Catch and Exception](https://stackoverflow.com/questions/11784320/how-does-throw-new-exception-inside-a-catch-work)                                                                                                                                                       |
| How to remove leading and trailing whitespaces - Geeksforgeeks                                                   | [Java Class Strip()](https://www.geeksforgeeks.org/java-string-class-strip-method-with-examples/)                                                                                                                                                                          |
| Features of Package java.util.regex - Oracle                                                                     | [Package java.util.regex](https://docs.oracle.com/javase/8/docs/api/)                                                                                                                                                                                                      |
| What does \p{P} mean - Stackoverflow                                                                             | [Regex \p{P}](https://tinyurl.com/47mzjku7)                                                                                                                                                                                                                                |
| What are regular Expressions - Stackoverflow                                                                     | [Regex Expressions](https://stackoverflow.com/questions/15625629/regex-expressions-in-java-s-vs-s)                                                                                                                                                                         |
| Java regex examples help understanding regex - Stackoverflow                                                     | [Regex Examples](https://stackoverflow.com/questions/51869576/java-regex-find-all-matches)                                                                                                                                                                                 |
| How replaceAll works and what \s and \s+ mean - Stackoverflow                                                    | [replaceAll, \\s and \\s+](https://stackoverflow.com/questions/15625629/regex-expressions-in-java-s-vs-s)                                                                                                                                                                  |
| How to split a string and separate by punctuation and whitespace(s) - Stackoverflow                              | [Class text.split()](https://tinyurl.com/msdvbne3)                                                                                                                                                                                                                         |
| What is the difference between List.of and Arrays.asList - Stackoverflow                                         | [List.of and Arrays.asList](https://stackoverflow.com/questions/46579074/what-is-the-difference-between-list-of-and-arrays-aslist)                                                                                                                                         |
| Substring in Java - Geeksforgeeks                                                                                | [str.Substring()](https://www.geeksforgeeks.org/substring-in-java/)                                                                                                                                                                                                        |
| What is AbstractCollection - Oracle                                                                              | [Class AbstractCollection](https://docs.oracle.com/javase/8/docs/api/)                                                                                                                                                                                                     |
| Collections in Java - Geeksforgeeks                                                                              | [Collections](https://www.geeksforgeeks.org/collections-in-java-2/)                                                                                                                                                                                                        |
| enum in Java - Geeksforgeeks                                                                                     | [enum](https://www.geeksforgeeks.org/enum-in-java/)                                                                                                                                                                                                                        |
| Generic Class in Java - Geeksforgeeks                                                                            | [Generic Class](https://www.geeksforgeeks.org/generic-class-in-java/)                                                                                                                                                                                                      |
| HashMap keySet() Method in Java - Geeksforgeeks                                                                  | [HashMap keySet()](https://www.geeksforgeeks.org/hashmap-keyset-method-in-java/)                                                                                                                                                                                           |
| Treemap in Java - Geeksforgeeks                                                                                  | [Treemaps](https://www.geeksforgeeks.org/treemap-in-java/)                                                                                                                                                                                                                 |
| Arrays.sort() in Java with Examples - Geeksforgeeks                                                              | [Arrays.sort()](https://www.geeksforgeeks.org/arrays-sort-in-java-with-examples/)                                                                                                                                                                                          |
| Collections.sort() in Java with Examples                                                                         | [Collections.sort()](https://www.geeksforgeeks.org/collections-sort-java-examples/)                                                                                                                                                                                        |
| Union Types in Java - Stackoverflow                                                                              | [Union types](https://stackoverflow.com/questions/49491593/union-types-in-java)                                                                                                                                                                                            |
| How the class StackTraceElement works - Oracle                                                                   | [class StackTraceElement](https://docs.oracle.com/javase//1.5.0/docs/api/java/lang/StackTraceElement.html#:~:text=public%20final%20class%20StackTraceElement%20extends%20Object%20implements%20Serializable,top%20of%20the%20stack%20represent%20a%20method%20invocation.) |
| Regular Expression Document - Salesforce                                                                         | [Regex Expressions](https://stackoverflow.com/questions/15625629/regex-expressions-in-java-s-vs-s)                                                                                                                                                                         |
| Java 11 documentation - Oracle                                                                                   | [java document](https://docs.oracle.com/en/java/javase/11/docs/api/)                                                                                                                                                                                                       |


| **The people that I have received knowledge and feedback from** | **How they helped**                                         |
|-----------------------------------------------------------------|-------------------------------------------------------------|
| Fiona Mcneill                                                   | provided the majority of knowledge I get from the lectures. |
| Neel Chaudhari                                                  | provided detailed feedback on part 1 of this assignment.    |
| Brian Mitchell                                                  | provided feedback and tips for this assignment.             |





## Code location ##

1. Verbosity : copy `verbosity` a3algorithms to literatureStats because they are same code and share same function.
They both defined verbosity as enumeration class, it defined five types with a specific value. 
2. SortingOrder: copy `SortingOrder` a3algorithms to literatureStats because they are same code and share same function.
They both defined five orders each associated with boolean value which show is reverse or not.
3. Translation: copy `VowelChecker` in `Translation` (line 20) a3algorithms to literatureStats because it require move the first non-vowel 
cluster to the end of the word. This is everything up to but not including the first vowel. So it require a function 
to check it vowel or not in first character.
4. Translation: copy `TrollSpeaker`in `Translation` (line 11) a3algorithms to literatureStats because they are same code and share same function.In
first two line of `Translation` is function with Translation. They both what every input in will convert grunt.
5. FrequencyWord: copy some code of Normaliser  a3algorithms to literatureStats. Because it has same functionality
   with `getNormalised()`(line 24,29).
6. FrequencyWord: copy getCount, incrementCount, toString and compareTo from `SimlpleFrequencyWord` to `FrequencyWord`
   (line29-63). It also has same structure with `SimlpleFrequencyWord`.
7. FrequencyDocumentReader : share same reader idea with AdvancedTextFileReader and BasicTextFileReader.


## DRY programming ##

There is an example in FrequencyDocumentReader shown that is dry programing. The mena idea of dry programming is 
avoiding duplication and promoting code reuse. So, in code of FrequencyDocumentReader it mainly have function which read 
the document. This code reads a document file then use FrequencyReaderConfig to process the words which is inputted
in file. 

It converts DEFAULT_NON_WORD_CHARS which remove non-word characters and normalise word. Then store it in to 
hashmap, then it process word as todo requirement. For specific example in FrequencyDocumentReader 
In `FrequencyDocumentReader` the function `DEFAULT_NON_WORD_CHARS`(line 15) is a good example of DRY coding, this regex 
is used very many times in the class, such as  in the`FrequencyDocumentReader`(lines 30)  ,`FrequencyDocument`(line 66, 
105 120 )  `FrequencyDocumentPG`(line 28,37 ).

In contrast, wet version of that use "[^a-zA-Z0-9'\\s]+" replace all the `DEFAULT_NON_WORD_CHARS`

In other hands, there are three function `FrequencyReaderConfig` which can get verbosity for words, Normaliser which remove
non-word characters and normalise word, Verbosity can check verbosity. By using this function it avoid defined each
function in three default settings.

In wet version, It will repeat function in `FrequencyReaderConfig` in the `FrequencyDocumentReader`

So in this wet version it duplicates same purpose code which have basic same functionality with Normaliser, 
FrequencyReaderConfig, Verbosity. It reuses similar code to get default for words.


## Relationships ##

In DataScientist, it directly uses `Translation` and `InformationDocument` which use `FrequencyWord` and `FrequencyDocument` 
which use `FrequencyReaderConfig` and `FrequencyDocumentReader`. So DataScientist indirectly use FrequencyWord, FrequencyDocument and 
FrequencyReaderConfig. 

**The part of direct use showing as below:**
- `InformationDocument`: search and get data from input.txt files (lines 84, 100), analyzes the data using 
   getTopNWords (lines 12, 48), getTopNWordsEnumerated (lines 24, 60), and getTopNFrequencyWords(lines 36, 70), 
   to get the top 3 most frequent words in different formats.
- `Translation`: translate top word to doggies language(lines 17,40,52,75).
- `SortingOrder`: use it in the `InformationDocument` method of data scientist (lines 14,25,36,48,60,71).

**The part of indirect use showing as below:**
- `FrequencyDocument` && `FrequencyDocumentPG`:some function use in  `InformationDocument` 
- `FrequencyDocumentReader`: readDocument method 
  are used by `FrequencyDocument` && `FrequencyDocumentPG` to read input.txt file, remove non-word characters, and returns unique
  words and their frequency as a TreeMap.
- `FrequencyReaderConfig`: it store configs in `FrequencyDocument` && `FrequencyDocumentPG`
- `FrequencyWord`: it store frequency and the word in `FrequencyDocument` && `FrequencyDocumentPG`.

The reason design as this way is that it fellow module design, it separates several function 
in different classes. Each classes in package to achieve certain purpose which can make file easy to understand,test 
and fix. This code is base on  principle of encapsulation which means bundling of data with the mechanisms or methods 
that operate on the data. The main features of encapsulation is that: 1.It provides extra security by the concept 
of Data Hiding. 2.It groups the data and operation in that data into a single unit. 3.It attaches an extra security 
layer to the data and allows to access data only to authorized ones.


## Explain reading a file ##

The FrequencyDocumentReader mainly function is that it read a document and create a treemap of words. In the 
readDocument() , first it scan the words line by line. Then it check the state of start marker and stop marker. If it 
contains in line, the words processing can continue. So if it is true, it will the readDocument() method normalizes 
the line by removing any non-word characters then split it into words. If word not exist it add in treemap string, if
it exists ,the frequency count will increase. Final if verbosity level is not silent it will print.

It uses several JDK methods such as toLowerCase(), replaceAll(), and Character.isLetterOrDigit().
The FrequencyDocumentReader class can fit to the DRY principle by reusing the readDocument() method with different 
levels of configuration options. 

This class divide the functionality in different function such as  it make normalizing the text, and producing the 
frequency hashmap into separate methods, making the code more modular and testable.

Before the introduction of try-with-resources in Java 7, it was necessary to use a try-catch-finally 
block to handle exceptions and close resources, which made the code more verbose and error possibility. 
With try-with-resources, it is only necessary to declare the resource to be used in the try statement, 
and Java will automatically close the resource when the try block is exited, whether normally or due 
to an exception.


## Explain the enums ##

The SortingOrder enum shows the different possible sorting orders in which a list 
of words can be sorted. The benefits of using an enum in this context are 
that it allows for easy and efficient checking of the sort order and ensures that only valid values 
are used.

Furthermore, the enum change easy to modify it can add new option is simply a 
matter of adding a new value to the enum. It also makes the code more readable,because it is clear 
what the different possible option are and what they mean.

The `Translation` enum show the different  translations of words. In this case, the enum defines
three possible translations: `NONE`, `TROLL` and `DOG`. Enums also allow
to switch which helps make the code more readable and avoid errors.

In `SortingOrder`, enums are used to evaluate the different levels of sorting in which a list of words can be sorted in. 
The benefits of using enums is that the SortingOrder ensures that only valid levels of sorting `NORMAL` `DESCENDING`
`ASCENDING` `REVERSED` `NOT_REVERSED` can be used, and it eliminates the need of magic numbers.

In `Verbosity`, enums are used to define the different levels of verbosity that can be
used when analyzing literature statistics. The Verbosity enum has four values, `SILENT`, `MINIMUM`,
`MEDIUM`, and `MAXIMUM`, each with a corresponding integer value for the level of verbosity.
Overall, the use of enums in this assignment is easy to read and modify.