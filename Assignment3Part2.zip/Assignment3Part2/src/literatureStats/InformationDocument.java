package literatureStats;

import java.util.*;
import java.util.stream.Collectors;


public class InformationDocument<T extends FrequencyDocument> {
    protected final T doc;

    public InformationDocument(Class<T> cls,
                               String filename) throws InstantiationException, IllegalAccessException {

        T d = cls.newInstance();
        this.doc = d;

        this.doc.initialise(filename);
        this.doc.readDocument();
    }


    public List<String> getTopNWords(int n, SortingOrder so) {
        List<String> topWords = new ArrayList<>();
        List<FrequencyWord> frequencyWords = getTopNFrequencyWords(n, so);

        for (FrequencyWord frequencyWord : frequencyWords) {
            topWords.add(frequencyWord.getNormalised());
        }

        return(topWords);
    }


    public List<String> getTopNWordsEnumerated(int n, SortingOrder so) {
        List<String> topWords = new ArrayList<>();
        List<FrequencyWord> frequencyWords = getTopNFrequencyWords(n, so);

        for (FrequencyWord frequencyWord : frequencyWords) {
            topWords.add(frequencyWord.toString(FrequencyWord.DEFAULT_WORD_STATS_PATTERN));
        }

        return(topWords);
    }


    public List<FrequencyWord> getTopNFrequencyWords(int n, SortingOrder so) {
        List<FrequencyWord> topWords = new ArrayList<>();
        Map<String, Integer> unsortedWordFreqMap = new HashMap<>();

        for (FrequencyWord frequencyWord : doc.words.values()) {
            unsortedWordFreqMap.put(frequencyWord.getNormalised(), frequencyWord.getCount());
        }

        List<String> sortedWords = sortWordsByFrequency(unsortedWordFreqMap, so);

        for (int i = 0; i < n && i < sortedWords.size(); i++) {
            String normalisedWord = sortedWords.get(i);
            FrequencyWord frequencyWord = doc.words.get(normalisedWord);
            topWords.add(frequencyWord);
        }

        return topWords;
    }

    private List<String> sortWordsByFrequency(Map<String, Integer> wordFrequency, SortingOrder sortingOrder) {
        Comparator<String> comparator = (w1, w2) -> {
            int freq1 = wordFrequency.get(w1);
            int freq2 = wordFrequency.get(w2);

            if (sortingOrder == SortingOrder.ASCENDING||sortingOrder == SortingOrder.NOT_REVERSED||sortingOrder == SortingOrder.NORMAL) {
                return Integer.compare(freq1, freq2);
            } else {
                return Integer.compare(freq2, freq1);
            }
        };
        return wordFrequency.keySet()
                .stream()
                .sorted(comparator)
                .collect(Collectors.toList());
    }



    public <K, V extends Comparable<? super V>> Map<K, V> sortByValue(
            Map<K, V> map, SortingOrder order) {
        List<Map.Entry<K, V>> list = new ArrayList<>(map.entrySet());
        if ( order.isReversed() ) {
            list.sort(Map.Entry.<K, V>comparingByValue().reversed());
        } else {
            list.sort(Map.Entry.comparingByValue());
        }

        Map<K, V> result = new LinkedHashMap<>();
        for ( Map.Entry<K, V> entry : list ) {
            result.put(entry.getKey(), entry.getValue());
        }

        return result;
    }


}
