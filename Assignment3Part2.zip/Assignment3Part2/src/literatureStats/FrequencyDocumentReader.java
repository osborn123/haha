package literatureStats;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

import static a3algorithms.Normaliser.normalise;

public class FrequencyDocumentReader {
    private FrequencyDocumentReader() {}

    public static final String DEFAULT_NON_WORD_CHARS = "[^a-zA-Z0-9'\\s]+";


    public static Map<String, FrequencyWord> readDocument(String dictionaryFileName) {
        return readDocument(new FrequencyReaderConfig(dictionaryFileName, null, null, Verbosity.SILENT));
    }


    public static Map<String, FrequencyWord> readDocument(String dictionaryFileName, String nonWordChars) {
        return readDocument(new FrequencyReaderConfig(dictionaryFileName, null, null, Verbosity.SILENT), nonWordChars);
    }


    public static Map<String, FrequencyWord> readDocument(FrequencyReaderConfig config) {

        return readDocument(config, DEFAULT_NON_WORD_CHARS);
    }


    public static Map<String, FrequencyWord> readDocument(FrequencyReaderConfig config, String nonWordChars) {
        Map<String, FrequencyWord> result = new TreeMap<>();
        boolean started = false, hasMarkers = (config.START_MARKER != null && config.STOP_MARKER != null);

        try (final Scanner sc = new Scanner(new File(config.DOCUMENT_FILENAME))) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine();

                if (hasMarkers) {
                    if (line.contains(config.START_MARKER)) {
                        started = true;
                        continue;
                    } else if (line.contains(config.STOP_MARKER)) {
                        break;
                    }
                } else if (!started) {
                    started = true;
                }

                if (started) {
                    String onlyWordsString = line.replaceAll(nonWordChars, " ");
                    String[] words = onlyWordsString.split("\\s+");
                    for (String word : words) {
                        if (word.length() > 0) {
                            FrequencyWord frequencyWord = new FrequencyWord(word);
                            String wordToAdd = frequencyWord.getNormalised();

                            if (!result.containsKey(wordToAdd)) {
                                result.put(wordToAdd, frequencyWord);
                                if (config.getVerbosity().getVerbosityLevel() > 0) {
                                    System.out.println("Added " + wordToAdd);
                                }
                            } else {
                                result.get(wordToAdd).incrementCount();
                                if (config.getVerbosity().getVerbosityLevel() > 0) {
                                    System.out.printf("Incremented %s to %d", wordToAdd, result.get(wordToAdd).getCount());
                                }
                            }
                        }
                    }
                }
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

        return result;
    }

}
