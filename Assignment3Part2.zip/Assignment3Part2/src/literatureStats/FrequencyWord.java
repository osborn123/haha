package literatureStats;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;


public class FrequencyWord implements Comparable<FrequencyWord> {
    public static final String DEFAULT_WORD_STATS_PATTERN = "%4d\t%s%n";


    public static final Set<String> VOWELS = new HashSet<>(Arrays.asList("a","e","i","o","u"));

    protected final String normalised;

    protected int count;

    FrequencyWord(String word) {
        count = 1;
        normalised = normalise(word);
    }


    public static String normalise(String word) {
        return word.toLowerCase().strip();
    }


    public String getNormalised() {
        return normalised;
    }



    public int getCount() {
        return count;
    }


    public void incrementCount() {
        count++;
    }


    @Override
    public String toString() {

        return String.format(DEFAULT_WORD_STATS_PATTERN, count, normalised);
    }


    public String toString(String wordStatePattern) {

        return String.format(wordStatePattern, count, normalised);
    }


    @Override
    public int compareTo(FrequencyWord other) {

        return Integer.compare(count, other.count);
    }
}
