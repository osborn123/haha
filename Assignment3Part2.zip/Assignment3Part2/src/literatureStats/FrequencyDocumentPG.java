package literatureStats;

public class FrequencyDocumentPG extends FrequencyDocument {
    public static final String PG_DOCUMENT_START =
            "*** START OF THE PROJECT GUTENBERG EBOOK";
    public static final String PG_DOCUMENT_STOP  =
            "*** END OF THE PROJECT GUTENBERG EBOOK";

    public FrequencyDocumentPG() {
        super();
    }


    public FrequencyDocumentPG(String filename) {
        this.initialise(filename);

    }


    public FrequencyDocumentPG(String filename, String nonWordChars) {
        this.initialise(filename, nonWordChars);

    }


    public FrequencyDocumentPG(FrequencyReaderConfig config) {
        super(config, FrequencyDocumentReader.DEFAULT_NON_WORD_CHARS);
    }


    public FrequencyDocumentPG(FrequencyReaderConfig config, String nonWordChars) {
        super(config, nonWordChars);
    }

    @Override
    public void initialise(String filename) {
        this.initialise(filename, FrequencyDocumentReader.DEFAULT_NON_WORD_CHARS);
    }


    @Override
    public void initialise(String filename, String nonWordChars) {
        setNonWordChars(nonWordChars);
        setConfig(new FrequencyReaderConfig(filename, PG_DOCUMENT_START, PG_DOCUMENT_STOP, Verbosity.SILENT));
        this.readDocument();
    }


}