package literatureStats;

import java.util.Map;

public class FrequencyDocument {


    protected Map<String, FrequencyWord> words;

    protected FrequencyReaderConfig config;

    protected String nonWordChars;


    public FrequencyDocument() {
        this.words        = null;
        this.config       = null;

        this.nonWordChars = null;
    }


    public FrequencyDocument(String filename) {
        this.initialise(filename);
        this.readDocument();
    }


    public FrequencyDocument(String filename, String nonWordChars) {
        this.initialise(filename, nonWordChars);
        this.readDocument();
    }


    public FrequencyDocument(FrequencyReaderConfig config) {
        this.initialise(config);
        this.readDocument();
    }


    public FrequencyDocument(FrequencyReaderConfig config, String nonWordChars) {
        this.initialise(config, nonWordChars);
        this.readDocument();
    }

    public void setConfig(FrequencyReaderConfig config) {
        this.config = config;
    }


    public void initialise(FrequencyReaderConfig config) {
        this.initialise(config, FrequencyDocumentReader.DEFAULT_NON_WORD_CHARS);
    }


    public void initialise(String filename) {
        this.initialise(new FrequencyReaderConfig(filename, null, null, Verbosity.SILENT), FrequencyDocumentReader.DEFAULT_NON_WORD_CHARS);
    }


    public void initialise(String filename, String nonWordChars) {
        this.initialise(new FrequencyReaderConfig(filename, null, null, Verbosity.SILENT), nonWordChars);
    }


    public void initialise(FrequencyReaderConfig config, String nonWordChars) {
        setConfig(config);
        setNonWordChars(nonWordChars);
        this.readDocument();
    }


    public String getNonWordChars() {
        return nonWordChars;
    }


    public void setNonWordChars(String nonWordChars) {
        this.nonWordChars = nonWordChars;
    }


    public void readDocument() {
        if(this.config != null && this.nonWordChars != null) {
            this.words = FrequencyDocumentReader.readDocument(this.config, this.nonWordChars);
        }
    }


    public String[] getStatsNormalisedWords() {
        return getStatsNormalisedWords(FrequencyWord.DEFAULT_WORD_STATS_PATTERN);
    }


    public String[] getStatsNormalisedWords(String pattern) {
        int i = 0;
        String[] stats = new String[words.size()];
        for (FrequencyWord word : words.values()) {
            stats[i] = word.toString(pattern);
            i++;
        }
        return stats;
    }


    public void printStatsNormalisedWords() {

        printStatsNormalisedWords(FrequencyWord.DEFAULT_WORD_STATS_PATTERN);
    }


    public void printStatsNormalisedWords(String pattern) {
        for(String stat : getStatsNormalisedWords(pattern)){
            System.out.println(stat);
        }
    }


}
