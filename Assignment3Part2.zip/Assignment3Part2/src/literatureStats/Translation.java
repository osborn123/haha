package literatureStats;

import java.util.Set;

import static literatureStats.FrequencyWord.VOWELS;


public enum Translation {
    NONE {@Override public String translate(String word) {return word;}},

    TROLL {@Override public String translate(String word) {
        word = "grunt";
        return word;
        }
    },

    DOG {
        @Override
        public String translate(String word) {
            if (word.equals("") || word == null){
                return ("");

            }

            else
            {
                final Set<Character> vowels = Set.of('a', 'e', 'i', 'o', 'u');
                final char first = word.charAt(0);

                int index = 0;
                for (; index < word.length(); index++) {
                    if (vowels.contains(word.charAt(index))) break;
                }

                String swapped_string = word.substring(index) + word.substring(0, index);
                switch (first) {
                    case 'b':
                        return swapped_string + "bark";

                    case 'g':
                        return swapped_string + "rrrowl";

                    case 'r':
                        return swapped_string + "rruf";

                    case 'w':
                        if (word.length() > 1 && word.charAt(1) == 'o') {
                            return swapped_string + "oofWoof";
                        } else {
                            return swapped_string + "oof";
                        }

                    default:
                        return swapped_string + "ay";
                }
            }
        }
    };
    public String translate(FrequencyWord frequencyWord) {

        return translate(frequencyWord.normalised);
    }


    public abstract String translate(String word);




}
