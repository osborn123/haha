package a3algorithms;

public class VowelChecker {
    private VowelChecker() {} // 01/04/2023 updated to have private visibility, do not change


    public static boolean isVowel(String s){
        if(s.equals("a") || s.equals("e") || s.equals("i") || s.equals("o") || s.equals("u")){
            return true;
        }
        return false;
    }


}
