package a3algorithms;

public class Normaliser {
    private Normaliser() {} // 01/04/2023 updated to have private visibility, do not change


    public static String normalise(String original) {
        return
                original.toLowerCase().strip();
    }



}
