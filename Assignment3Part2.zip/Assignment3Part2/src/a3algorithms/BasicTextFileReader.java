package a3algorithms;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static a3algorithms.Normaliser.normalise;

public class BasicTextFileReader {
    private BasicTextFileReader() {} // 01/04/2023 updated to have private visibility, do not change



    public static List<String> readFile(String filename) {

        final String charsToDelete = "[^A-Za-z0-9'\\s]+";
        List<String> result = new ArrayList<>();

        try ( final Scanner sc = new Scanner(new File(filename)) ) {
            while ( sc.hasNextLine() ) {
                String line = sc.nextLine();

                String[] words = normalise(line.replaceAll(charsToDelete, "")).split("\\s+");
                for (String word : words) {
                    if(word.length() > 0) {
                        if(!result.contains(word)){
                            result.add(word);
                        }
                    }
                }

            }
        } catch ( FileNotFoundException e ) {
            throw new RuntimeException(e);
        }

        return result;
    }



}
