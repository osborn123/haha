package a3algorithms;


public class SimpleFrequencyWord implements Comparable<SimpleFrequencyWord> {
    protected final String word;
    protected int count;


    SimpleFrequencyWord(String word) {
        this.word = word;
        count = 1;
    }


    public String getWord() {
        return word;
    }


    public int getCount() {
        return count;
    }


    public void incrementCount() {
        count++;
    }


    @Override
    public String toString() {
        return String.format("%4d\t%s", count, word);
    }


    public String toString(String wordStatePattern) {
        return String.format(wordStatePattern, count, word);
    }


    @Override
    public int compareTo(SimpleFrequencyWord other) {
        return Integer.compare(count, other.count);
    }


}
