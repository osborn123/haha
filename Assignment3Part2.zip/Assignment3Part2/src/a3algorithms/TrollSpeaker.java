package a3algorithms;

public class TrollSpeaker {
    private TrollSpeaker() {} // 01/04/2023 updated to have private visibility, do not change


    public static String translateIntoTroll(String original) {
        return "grunt";
    }


}
